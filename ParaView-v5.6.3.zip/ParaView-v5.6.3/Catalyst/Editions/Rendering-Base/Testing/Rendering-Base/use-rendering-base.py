from paraview.simple import *

Sphere()
Show()
Render()
WriteImage('rendering-base.png')
