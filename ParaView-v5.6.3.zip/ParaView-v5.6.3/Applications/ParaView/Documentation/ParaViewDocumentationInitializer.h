#ifndef ParaViewDocumentationInitializer_h
#define ParaViewDocumentationInitializer_h

void PARAVIEW_DOCUMENTATION_INIT();

#endif
